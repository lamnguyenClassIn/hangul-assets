# Hangul Stroke-Order Library (v2 — confirmed 7-cell MIZI layout)

All geometry is precomputed and frozen into static SVG files at **build time**.
The runtime AI (whatever model — Gemini, or a Qwen-based AgentIn) performs **zero
geometry computation**. It only needs to look up the character in `manifest.json`
and serve the matching file.

## Structure

```
jamo/           51 files — 24 base Jamo (14 consonants + 10 vowels) + 27 extended
                (5 tense consonants, 9 level-1 compound vowels, 2 level-2 compound
                vowels, 11 double-finals)
syllables/      11,172 files — every valid modern Hangul syllable (Unicode AC00-D7A3)
manifest.json   lookup table: character -> file path + metadata
README.md       this file
```

Filename pattern: `<Unicode code, zero-padded>_<character>.svg`
e.g. `10661_향.svg`, `jamo/03145_ㅅ.svg`.

## Confirmed row layout

**Syllable file (7 cells in one row, one self-contained SVG):**

| Cell | Content |
|---|---|
| 1 | Complete stroke model - numbered arrows (1, 2, 3...), color-coded: red = initial, blue = medial, green = final |
| 2 | Block-structure diagram - colored regions labeled `initial` / `medial` / `final`, no caption text underneath (removed per feedback) |
| 3 | Practice cell with a faint gray trace guide (same shape as cell 1, light gray) |
| 4-7 | Practice cells, fully blank - grid guide only (dashed cross-hair, 4 quadrants) |

**Jamo file (6 cells in one row):** same idea, minus the block-diagram cell (a
standalone Jamo has no initial/medial/final structure to show) - 1 model cell + 5
practice cells (first faint, rest blank).

## Runtime lookup (no computation)

```
entry = manifest["syllables"].get(char) or manifest["jamo"].get(char)
if entry is None:
    # char is not a valid Hangul syllable/Jamo - fail the lookup, do not draw
    ...
else:
    serve file at entry["file"]   # already a complete, IFP-portable SVG
```

To render a multi-character string, place each character's file's `<svg>` next to
the previous one (simple x-offset placement) - this is positioning, not stroke
reconstruction.

## What changed from v1

- Removed the circle-badge stroke numbers -> plain small digits next to the arrow (less visual clutter).
- Arrowheads made smaller.
- New row structure: model cell -> block-diagram cell -> 5 practice cells (previously
  a single 5-cell fade progression with no block-diagram or dedicated model-only cell).
- Removed the caption line (formula + block-type text) under the block-diagram cell.

## Known limitation (unchanged from v1)

Extended Jamo (tense consonants, compound vowels, double-finals) are composed by a
generic side-by-side algorithm, not hand-authored per-compound coordinates. Stroke
count/order/shape are correct; a few visually dense compound-final syllables (e.g.
겹받침 + compound vowel together) can look slightly cramped.
